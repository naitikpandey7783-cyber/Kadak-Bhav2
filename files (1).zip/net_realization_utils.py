"""
Real-world Net Realization utilities.

Replaces the Task 8 prototype's synthetic distance (np.random.randint)
and synthetic buyer reliability (np.random.uniform) with calculations
that run on real data:

- Distance: Haversine great-circle distance from real market/farmer
  coordinates (lat/lon), with an optional road-distance approximation
  factor. Swap in a routing API (OSRM / OpenRouteService / Google Maps
  Distance Matrix) for true road distances when you have API access.
- Buyer reliability: computed from actual transaction records
  (completed / cancelled / disputed / payment delay), not guessed.
  Markets with no transaction history yet get an explicit
  "insufficient_data" flag and a neutral default score instead of a
  fabricated number.
- Transport cost: now actually uses vehicle capacity — quantities
  larger than one vehicle load require multiple trips, each costing
  the full distance-based fare again.
"""
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# 1. Real distance (Haversine)
# ---------------------------------------------------------------------
EARTH_RADIUS_KM = 6371.0

# Straight-line (great-circle) distance is always shorter than the
# actual road route. This factor is a widely used rough approximation
# for road-vs-straight-line ratio in the absence of a routing API.
# Replace with a real routing API call when available.
ROAD_DISTANCE_FACTOR = 1.3


def haversine_distance_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km between two (lat, lon) points."""
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = (
        np.sin(dlat / 2.0) ** 2
        + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    )
    c = 2 * np.arcsin(np.sqrt(a))

    return EARTH_RADIUS_KM * c


def compute_real_distances(
    market_coordinates: pd.DataFrame,
    farmer_lat: float,
    farmer_lon: float,
    road_factor: float = ROAD_DISTANCE_FACTOR,
) -> pd.DataFrame:
    """
    market_coordinates must have columns: market, latitude, longitude.
    Returns a copy with a real 'distance_km' column (approximate road
    distance from the farmer's location to each market).
    """
    required = {"market", "latitude", "longitude"}
    missing = required - set(market_coordinates.columns)
    if missing:
        raise ValueError(
            f"market_coordinates is missing columns: {missing}. "
            "Fill in real coordinates in market_coordinates_template.csv."
        )

    result = market_coordinates.copy()

    straight_line_km = haversine_distance_km(
        farmer_lat, farmer_lon,
        result["latitude"], result["longitude"],
    )

    result["distance_km"] = straight_line_km * road_factor
    return result[["market", "distance_km"]]


# ---------------------------------------------------------------------
# 2. Transport cost — now actually uses vehicle capacity
# ---------------------------------------------------------------------
def compute_transport_cost(
    distance_df: pd.DataFrame,
    quantity_kg: float,
    vehicle_capacity_kg: float,
    cost_per_km: float = 12,
    fixed_cost_per_trip: float = 0,
) -> pd.DataFrame:
    """
    distance_df must have columns: market, distance_km.
    A quantity larger than one vehicle load needs multiple trips;
    each trip re-travels the full distance, so cost scales with
    trips, not just distance.
    """
    result = distance_df.copy()

    trips_needed = int(np.ceil(quantity_kg / vehicle_capacity_kg))
    result["trips_needed"] = trips_needed

    result["transport_cost"] = (
        (result["distance_km"] * cost_per_km + fixed_cost_per_trip)
        * trips_needed
    )

    result["transport_cost_per_kg"] = (
        result["transport_cost"] / quantity_kg
    )

    return result


# ---------------------------------------------------------------------
# 3. Buyer reliability — computed from real transactions, not guessed
# ---------------------------------------------------------------------
DEFAULT_RELIABILITY_FOR_NEW_MARKETS = 0.75
MIN_TRANSACTIONS_FOR_CONFIDENCE = 5


def compute_buyer_reliability(
    transactions: pd.DataFrame,
    markets: pd.Series,
    min_transactions: int = MIN_TRANSACTIONS_FOR_CONFIDENCE,
    default_score: float = DEFAULT_RELIABILITY_FOR_NEW_MARKETS,
) -> pd.DataFrame:
    """
    transactions must have columns:
        market, status ('completed' | 'cancelled' | 'disputed'),
        payment_delay_days
    markets: the set of markets you need a score for (e.g. from
        market_performance['market']).

    Returns one row per market with:
        buyer_reliability_score, transaction_count, data_confidence
    Markets with fewer than `min_transactions` records get
    data_confidence='insufficient_data' and the neutral default_score
    instead of a computed (unreliable) score.
    """
    required = {"market", "status", "payment_delay_days"}
    missing = required - set(transactions.columns)
    if missing:
        raise ValueError(
            f"transactions is missing columns: {missing}. "
            "Log real platform transactions in this shape "
            "(see buyer_transactions_template.csv)."
        )

    grouped = transactions.groupby("market")

    def _score(g):
        total = len(g)
        completed = (g["status"] == "completed").sum()
        cancelled = (g["status"] == "cancelled").sum()
        disputed = (g["status"] == "disputed").sum()

        completion_rate = completed / total
        cancellation_rate = cancelled / total
        dispute_rate = disputed / total

        # Payment delay: 0 days = no penalty; cap penalty at 30+ days.
        avg_delay = g["payment_delay_days"].clip(lower=0).mean()
        timeliness = 1 - min(avg_delay / 30.0, 1.0)

        score = (
            0.5 * completion_rate
            + 0.2 * (1 - cancellation_rate)
            + 0.2 * (1 - dispute_rate)
            + 0.1 * timeliness
        )

        return pd.Series({
            "buyer_reliability_score": round(float(score), 4),
            "transaction_count": total,
        })

    computed = grouped.apply(_score).reset_index()

    result = pd.DataFrame({"market": markets.unique()})
    result = result.merge(computed, on="market", how="left")

    result["transaction_count"] = result["transaction_count"].fillna(0).astype(int)

    result["data_confidence"] = np.where(
        result["transaction_count"] >= min_transactions,
        "sufficient",
        "insufficient_data",
    )

    result["buyer_reliability_score"] = np.where(
        result["data_confidence"] == "sufficient",
        result["buyer_reliability_score"],
        default_score,
    )

    return result


# ---------------------------------------------------------------------
# 4. Full recommendation, wired to real inputs
# ---------------------------------------------------------------------
def recommend_best_market_real(
    market_performance: pd.DataFrame,
    market_coordinates: pd.DataFrame,
    transactions: pd.DataFrame,
    farmer_lat: float,
    farmer_lon: float,
    quantity_kg: float,
    vehicle_capacity_kg: float,
    cost_per_km: float = 12,
    fixed_cost_per_trip: float = 0,
    average_speed_kmph: float = 40,
    risk_weight: float = 0.10,
    perishability_rate_per_day: float = 0.03,
) -> pd.DataFrame:
    """
    Same net-realization math as the Task 8 prototype, but every input
    is now either real (distance from real coordinates, reliability
    from real transactions) or an explicit, labeled default rather
    than a random number.
    """
    quantity_quintal = quantity_kg / 100

    distances = compute_real_distances(
        market_coordinates, farmer_lat, farmer_lon
    )
    distances = compute_transport_cost(
        distances, quantity_kg, vehicle_capacity_kg,
        cost_per_km, fixed_cost_per_trip,
    )

    reliability = compute_buyer_reliability(
        transactions, market_performance["market"]
    )

    result = market_performance.merge(distances, on="market", how="left")
    result = result.merge(reliability, on="market", how="left")

    result["predicted_revenue"] = result["predicted_avg"] * quantity_quintal

    result["travel_time_hours"] = result["distance_km"] / average_speed_kmph
    result["travel_time_days"] = result["travel_time_hours"] / 24

    result["reliability_penalty"] = (
        (1 - result["buyer_reliability_score"])
        * risk_weight
        * result["predicted_revenue"]
    )

    result["perishability_penalty"] = (
        result["predicted_revenue"]
        * perishability_rate_per_day
        * result["travel_time_days"]
    )

    result["net_realization"] = (
        result["predicted_revenue"]
        - result["transport_cost"]
        - result["reliability_penalty"]
        - result["perishability_penalty"]
    )

    result["net_per_quintal"] = result["net_realization"] / quantity_quintal

    result = result.sort_values(
        "net_realization", ascending=False
    ).reset_index(drop=True)

    result["rank"] = result.index + 1

    return result
